from __future__ import print_function
from fenics import *
import os
import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
from mshr import *
set_log_active(False)

# Create mesh and function spaces.
mesh = Mesh('./mesh-file/mesh.xml')
meshfile=File('./tension_results/new_delta_Temp_top+50K/tension_PF.pvd')
n = FacetNormal(mesh)

#mesh = Mesh('./shear_msh_files/tension_elastic_pfm_fine.xml')
#markers = MeshFunction("size_t", mesh,'./shear_msh_files/tension_elastic_pfm_fine_physical_region.xml')
#boundaries = MeshFunction('size_t', mesh,'./shear_msh_files/tension_elastic_pfm_fine_facet_region.xml')

#n = FacetNormal(mesh)
#ds = Measure('ds', domain=mesh, subdomain_data=boundaries)

#------------------------------------------------
#          Define Space
#------------------------------------------------

W = FunctionSpace(mesh,'CG',1) # for phase field variable
p , q = TrialFunction(W), TestFunction(W)

V = VectorFunctionSpace(mesh, "CG", 1)
du = TrialFunction(V)
u_ = TestFunction(V)

WW = FunctionSpace(mesh, 'DG', 0) # for history variable 

VT = FunctionSpace(mesh, 'CG', 1) # for temperature
Tempu, Tempv  = TrialFunction(VT), TestFunction(VT)

TT = TensorFunctionSpace(mesh, 'CG', 1)  #for Stress Tensor field

Z = FunctionSpace(mesh,'CG',1)  # for sigm-max variable 
ZZ = FunctionSpace(mesh, 'DG', 0) # for sigm-max plot

#------------------------------------------------
#           Parameters
#------------------------------------------------

Gc =  42.47
l = 0.005e-3

E=340e+9
nu=0.22
lmbda = E*nu/(1.0+nu)/(1.0-2.0*nu)
mu = E/2.0/(1.0+nu)

alpha = 8e-6
rho = 2450  #density
Cp = 0.775  # specific heat
K = 300	 # thermal conductivity

Temp0 = 300

#------------------------------------------------
# giving time steps 
#------------------------------------------------

t = 0
max_load = 10e-6
deltaT  = 5e-10

Load_time = 2000e-10
Tempx = 0
delta_temp = 0.125
Max_Temp = 50

ut = 1
counter = 0

#------------------------------------------------
#           Classes
#------------------------------------------------

def epsilon(u):
    return 0.5*(grad(u) + grad(u).T)

def epsilon_thermal(Temp,Temp0):
    return alpha*(Temp-Temp0)*Identity(2)

def epsilon_elastic(u, Temp,Temp0):
    return epsilon(u) - epsilon_thermal(Temp,Temp0)
    
# thermo mechanical constituitive equation for sigma(u, Temp, Temp0)    
def sigma(u, Temp,Temp0):
	return 2.0*mu*epsilon_elastic(u, Temp, Temp0) + lmbda*tr(epsilon_elastic(u, Temp, Temp0))*Identity(2)

# trace of positive part of spectrally decomposed "elastic strain "	
def strain_positive(u, Temp, Temp0):
    et = epsilon_elastic(u, Temp, Temp0)
    v00=0.5*(tr(et)+((tr(et))**2-4*(det(et)))**0.5)
    v11=0.5*(tr(et)-((tr(et))**2-4*(det(et)))**0.5)
    return (0.5*(v00+abs(v00)))**2 + (0.5*(v11+abs(v11)))**2
    
# anisotropically degrading elastic strain energy
    
def psi(u, Temp, Temp0):
    return 0.5*lmbda*( 0.5*(tr(epsilon_elastic(u, Temp, Temp0)) + abs(tr(epsilon_elastic(u, Temp, Temp0)))) )**2 \
     + mu* strain_positive(u, Temp, Temp0)

History_old =  Function(W)
def History_positive(u_new, Temp_sol, History_old, Temp0):
    return conditional(lt(History_old,psi(u_new,Temp_sol, Temp0)),psi(u_new,Temp_sol, Temp0),History_old)

#----------------------------
# Define Boundaries
#----------------------------

class top(SubDomain):
    def inside(self,x,on_boundary):
        tol = 1e-13
        return abs(x[1]-1e-3) < tol and on_boundary

class bottom(SubDomain):
    def inside(self,x,on_boundary):
        tol = 1e-13
        return abs(x[1]) < tol and on_boundary
        
class middle(SubDomain): 
    def inside(self,x,on_boundary):
        tol = 1e-6
        return abs(x[1]-0.5e-3) < tol and (x[0]-0.5e-3) <= 0.0

#class left(SubDomain):
    #def inside(self,x,on_boundary):
        #tol = 1e-10
        #return abs(x[0]) < tol and on_boundary
        
#class right(SubDomain):
    #def inside(self,x,on_boundary):
        #tol = 1e-10
        #return abs(x[0]-1) < tol and on_boundary

Middle = middle()   
Top = top()
Bottom = bottom()

#Right = right()
#Left = left()

boundaries = MeshFunction("size_t", mesh, mesh.topology().dim() - 1)

boundaries.set_all(0)
Bottom.mark(boundaries,1)
Top.mark(boundaries,3)
#Right.mark(boundaries,3)
#Left.mark(boundaries,4)
Middle.mark(boundaries,10)

meshfile<<boundaries

#raise SystemExit()

#ds = Measure("ds")[boundaries]
ds = Measure('ds',subdomain_data=boundaries)

#----------------------------
# Define Boundary Condition
#----------------------------

#Temp0 = 0.0

Temp_D_initial = Constant(Temp0)
Temp_n = interpolate(Temp_D_initial, VT)

Temp_D1 =  Constant(Temp0)
Temp_D2 =  Expression("t",t = 0.0, degree = 2)

bcT = [DirichletBC(VT, Temp_D1, boundaries,1), 
       DirichletBC(VT, Temp_D2, boundaries,3)]

u_Lx = Expression("t",t = 0.0, degree = 2)

bc_1 = DirichletBC(V.sub(0),Constant(0), boundaries,1)
bc_2 = DirichletBC(V.sub(1),Constant(0), boundaries,1)
bc_3= DirichletBC(V.sub(1), u_Lx, boundaries,3)
bc_4= DirichletBC(V.sub(0), Constant(0), boundaries,3)

bc_u = [bc_1, bc_2, bc_3,bc_4]

bc_phi = DirichletBC(W, Constant(1), boundaries,10)

#----------------------------------------
# Define necessary functions
#----------------------------------------

#Current (unknown) displacement
u_new = Function(V, name="Displacement")
u_old2= Function(V)

# Fields from previous time step (displacement, velocity, acceleration)
u_old= Function(V)
v_old = Function(V)
a_old = Function(V)

pnew, pold = Function(W), Function(W)
Temp_sol, Temp_old = Function(VT), Function(VT)

v_reac = Function(V)
s1_max = Function(Z)
s1_s2 = Function(Z)
History_old =  Function(W)
strain_energy =  Function(W)

#----------------------------------------
# Define variational form of Displacement
#----------------------------------------

E_disp = (pow((1-pnew),2) + 1e-6)*inner(grad(u_),sigma(du,Temp_sol,Temp0))*dx 

problem_disp = LinearVariationalProblem(lhs(E_disp), rhs(E_disp), u_new, bc_u)

solver_disp = LinearVariationalSolver(problem_disp)

#----------------------------------------
# Define variational form of phi
#----------------------------------------

E_phi = (Gc*l*inner(grad(p),grad(q))+((Gc/l)+\
		2.0*History_positive(u_new, Temp_sol, History_old,Temp0))\
        *inner(p,q)- 2.0*History_positive(u_new, Temp_sol, History_old,Temp0)*q)*dx 

#problem_phi = LinearVariationalProblem(lhs(E_phi), rhs(E_phi), pnew)
problem_phi = LinearVariationalProblem(lhs(E_phi), rhs(E_phi), pnew,bc_phi)

solver_phi = LinearVariationalSolver(problem_phi)

#--------------------------------------------------------------------------------------
# Define variational form of Temperature
#--------------------------------------------------------------------------------------

E_Temp = (rho*Cp*(Tempu)*Tempv + (pow((1-pnew),2) + 1e-6)*K*deltaT * dot(grad(Tempu), grad(Tempv))\
		 - rho*Cp*(Temp_n)*Tempv)*dx

problem_Temp = LinearVariationalProblem(lhs(E_Temp), rhs(E_Temp), Temp_sol, bcT)

solver_Temp = LinearVariationalSolver(problem_Temp)

#----------------------------------------
# Define  Energy 
#----------------------------------------

EnergyOO = 0.0

Potential_E = ((1 - pnew)**2 + 1e-6)*inner(epsilon_elastic(u_new, Temp_sol,Temp0),sigma(u_new,Temp_sol,Temp0))*dx

#Kinetic_E  = 0.5*rho*dot(v_old, v_old)*dx

Fracture_E = (0.5*Gc)*(l*dot(grad(pnew), grad(pnew)) + (1/l)*pow(pnew,2))*dx

Total_E1 = Potential_E + Fracture_E 

#Total_E2 = Potential_E + Fracture_E + Kinetic_E

#----------------------------------------

file_1 = File ("./tension_results/new_delta_Temp_top+50K/phi/phi.pvd")
file_2 = File ("./tension_results/new_delta_Temp_top+50K/temp/temp.pvd")
file_3 = File ("./tension_results/new_delta_Temp_top+50K/disp/u.pvd")
file_4 = File ("./tension_results/new_delta_Temp_top+50K/Maximum_stress/sigma_max.pvd")
file_5 = File ("./tension_results/new_delta_Temp_top+50K/s1_s2/s1_s2.pvd")

Rx_botx = 0.0
Rx_topx = 0.0
Rx_boty = 0.0
Rx_topy = 0.0
Rx_botmag = 0.0
Rx_topmag = 0.0

fname1 = open('./tension_results/new_delta_Temp_top+50K/botedge_ForcevsDisp_tension_geo+pfm_iso_new_delta_Temp_top+50K.txt', 'w')
fname2 = open('./tension_results/new_delta_Temp_top+50K/topedge_ForcevsDisp_tension_geo+pfm_iso_new_delta_Temp_top+50K.txt', 'w')
fname3 = open('./tension_results/new_delta_Temp_top+50K/overall_EnergyvsDisp_tension_geo+pfm_iso_new_delta_Temp_top+50K.txt', 'w')


while t<= max_load:
	
	if t > 6000e-10:
		deltaT = 1e-10
		
	#Temp_D1.t = Temp0-(Tempx)
	Temp_D2.t = Temp0+(Tempx)
	

	t+=deltaT
	u_Lx.t=t*ut
	
	
	iter = 0
	toll = 1e-2
	err = 1
	err_phi = 1
	
	while err_phi > toll:

		while err > toll: 
			
			solver_Temp.solve()
			solver_disp.solve()
			
			err_Temp = errornorm(Temp_sol,Temp_old, norm_type = 'l2',mesh = None)/(norm(Temp_sol)+1e-5)
			print ('err_Temp =',err_Temp)
					
			err_u = errornorm(u_new,u_old2,norm_type = 'l2',mesh = None)/(norm(u_new)+1e-5)
			print ('err_disp =',err_u)
						
			err = max(err_u, err_Temp)
			print('error_max for u and temp =', err)
			
			Temp_old.assign(Temp_sol)
			u_old2.assign(u_new)			
			
			#1
						
			if err < toll:
			
				solver_phi.solve()
			
				err_phi= errornorm(pnew,pold,norm_type = 'l2',mesh = None)/(norm(pnew)+1e-5)
				print ('err_phi =',err_phi)
				
				err = max(err_u,err_phi,err_Temp)
				print('error_max of the 3 values  =', err)
				
				
				history_project = project(History_positive(u_new, Temp_sol, History_old,Temp0), WW)
				History_old.assign(history_project)
				print (History_old.vector().get_local().max())
				
				pold.assign(pnew)				
				
				iter = iter + 1
				
				if err_phi < toll:
					
					print('_slow tension+Top+50 error_max after the 3 after converged  =', err)
					
					Temp_n.assign(Temp_sol)				
			
					
					print ('_slow tension+Top+50 to converge phi no of iter :', iter, ', Total time: ', t)
					
								
					if t <= 2:
						
						if counter%1== 0:

							residual = action(lhs(E_disp), u_new) - rhs(E_disp)
							
							bcRx_botx = DirichletBC(V.sub(0), Constant(1.0), boundaries, 1)
							bcRx_topx = DirichletBC(V.sub(0), Constant(1.0), boundaries, 3)	

							bcRx_boty = DirichletBC(V.sub(1), Constant(1.0), boundaries, 1)
							bcRx_topy = DirichletBC(V.sub(1), Constant(1.0), boundaries, 3)	
							
							v_reac.interpolate(Constant((0., 0.)))
							bcRx_botx.apply(v_reac.vector())
							fname1.write(str(t) + "\t" + "\t")	
							Rx_botx = (assemble(action(residual, v_reac)))
							fname1.write(str(Rx_botx) + "\t" + "\t")
							
							v_reac.interpolate(Constant((0., 0.)))
							bcRx_boty.apply(v_reac.vector())
							Rx_boty = (assemble(action(residual, v_reac)))
							fname1.write(str(Rx_boty) + "\t" + "\t")
							
							Rx_botmag = sqrt((Rx_boty**2)+(Rx_botx**2))
							fname1.write(str(Rx_botmag) + "\n")					
							
							v_reac.interpolate(Constant((0., 0.)))
							bcRx_topx.apply(v_reac.vector())
							fname2.write(str(t) + "\t" + "\t")	
							Rx_topx = (assemble(action(residual, v_reac)))
							fname2.write(str(Rx_topx) + "\t" + "\t")
							
							v_reac.interpolate(Constant((0., 0.)))
							bcRx_topy.apply(v_reac.vector())
							Rx_topy = (assemble(action(residual, v_reac)))
							fname2.write(str(Rx_topy) + "\t" + "\t")
							
							Rx_topmag = sqrt((Rx_topy**2)+(Rx_topx**2))
							fname2.write(str(Rx_topmag) + "\n")														

							fname3.write(str(t) + "\t" + "\t")
							fname3.write(str(assemble(Potential_E)) + "\t" + "\t")
							fname3.write(str(assemble(Fracture_E)) + "\t" + "\t")
							fname3.write(str(assemble(Total_E1)) + "\n")
						
						if counter%100== 0:
							
							print("counter while dumping solution is ", counter )

							sigma_w = project(sigma(u_new, Temp_sol,Temp0),TT)							
							sigma_max = 0.5*(sigma_w[0,0] + sigma_w[1,1]) + sqrt(  (0.5*(sigma_w[0,0] - sigma_w[1,1]))**2 + (sigma_w[0,1])**2  )
							sigma_min = 0.5*(sigma_w[0,0] + sigma_w[1,1]) - sqrt(  (0.5*(sigma_w[0,0] - sigma_w[1,1]))**2 + (sigma_w[0,1])**2  )
							sigma_diff = sigma_max-sigma_min
							
							s1_max_project = project((sigma_max),ZZ)
							s1_max.assign(s1_max_project)
							
							s1_s2_project = project((sigma_diff),ZZ)
							s1_s2.assign(s1_s2_project)					
													
							file_1 << pnew , t
							file_2 << Temp_sol , t
							file_3 << u_new , t
							file_4 << s1_max, t
							file_5 << s1_s2, t

							
					if t < Load_time :
														
						Tempx = (Tempx+delta_temp)
						
					elif t >= Load_time:
						
						Tempx = (Max_Temp)
				
													
					counter += 1					
					#t+=deltaT
									
fname1.close()
fname2.close()
fname3.close()	

print ('Up Above the world so high') 


    



	


